package com.example.livedata

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MyViewModel : ViewModel() {
    val saveData: MutableLiveData<String> by lazy {
        MutableLiveData<String>()
    }
}