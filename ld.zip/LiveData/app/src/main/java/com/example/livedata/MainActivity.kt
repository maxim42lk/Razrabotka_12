package com.example.livedata

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.Observer



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val model: MyViewModel by viewModels()
        val button: Button = findViewById(R.id.button1)
        val textView: TextView = findViewById(R.id.TextView1)
        val nameObserver = Observer<String> { newText ->
            textView.text = newText
        }
        model.saveData.observe(this, nameObserver)
        button.setOnClickListener {
            model.saveData.setValue("Проверочный текст!")
        }
    }
}
